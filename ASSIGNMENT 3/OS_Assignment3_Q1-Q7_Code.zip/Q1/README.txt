AIM
Demonstrate static linking, shared-library linking, runtime loading and address binding.

SOURCE FILES
crypto.h, crypto.c, runtime_bank.c

COMPILE
gcc -Wall -Wextra -c crypto.c -o crypto.o
ar rcs libcrypto.a crypto.o
gcc -Wall -Wextra runtime_bank.c crypto.o -ldl -o runtime_bank_static
gcc -fPIC -shared crypto.c -o libcrypto.so
gcc -Wall -Wextra runtime_bank.c -L. -lcrypto -Wl,-rpath,'$ORIGIN' -ldl -o runtime_bank

EXECUTE
./runtime_bank_static
LD_LIBRARY_PATH=. ./runtime_bank
For a live PID/maps inspection, run the program in a second terminal or temporarily add a pause:
cat /proc/<PID>/maps | grep -E 'runtime_bank|libcrypto.so'

REQUIRED LINUX COMMANDS
file runtime_bank_static runtime_bank
size runtime_bank_static runtime_bank
ldd ./runtime_bank
nm -D ./libcrypto.so
readelf -d ./runtime_bank
The dynamic-loader demonstration uses dlopen()/dlsym(); -ldl is required on systems where these functions are in libdl.

EXPECTED OUTPUT
The program prints a linked-call encryption line, a runtime-loading line, a second encrypted message and a successful close message. Addresses and PID in /proc are machine/process dependent.
