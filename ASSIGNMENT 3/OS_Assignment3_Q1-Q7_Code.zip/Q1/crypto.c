#include <stdio.h>
#include "crypto.h"

void encrypt_message(const char *message)
{
    printf("Encrypted message: ");
    for (int i = 0; message[i] != '\0'; ++i)
        putchar((unsigned char)message[i] + 1);
    putchar('\n');
}
