#ifndef CRYPTO_H
#define CRYPTO_H
void encrypt_message(const char *message);
#endif
