#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include "crypto.h"

typedef void (*encrypt_fn)(const char *);

int main(void)
{
    const char *message = "BANK TRANSACTION";
    puts("Q1: Linking, loading and address binding");
    puts("[Linked call]");
    encrypt_message(message);

    puts("[Runtime loading with dlopen/dlsym]");
    void *handle = dlopen("./libcrypto.so", RTLD_NOW);
    if (!handle) {
        fprintf(stderr, "dlopen failed: %s\n", dlerror());
        return EXIT_FAILURE;
    }

    dlerror();
    encrypt_fn encrypt = (encrypt_fn)dlsym(handle, "encrypt_message");
    const char *error = dlerror();
    if (error) {
        fprintf(stderr, "dlsym failed: %s\n", error);
        dlclose(handle);
        return EXIT_FAILURE;
    }
    encrypt("RUNTIME BANK");
    dlclose(handle);
    puts("Runtime library closed successfully.");
    puts("Inspect mappings in another terminal with: cat /proc/<PID>/maps");
    return EXIT_SUCCESS;
}
