AIM
Simulate logical-to-physical address translation using a page table, showing page number, offset, invalid address and page fault.

SOURCE FILE
paging.c

COMPILE
gcc -std=c11 -Wall -Wextra paging.c -o paging

EXECUTE
./paging
getconf PAGESIZE
/usr/bin/time -v ./paging

REQUIRED LINUX COMMANDS
getconf PAGESIZE
/usr/bin/time -v ./paging

EXPECTED OUTPUT
With PAGE_SIZE=1024, the reference logical addresses are 0, 1500, 3100, 6200, 9000 and 2049. The first four valid resident pages translate to physical addresses; 9000 is outside the simulated page table; page 2 is marked nonresident and reports a page fault. getconf reports the host's actual OS page size, which may differ from this teaching simulation.
