#include <stdio.h>
#define PAGE_SIZE 1024u
#define PAGE_COUNT 8u

int main(void)
{
    /* -1 means that the page is not resident in the simulated page table. */
    const int page_table[PAGE_COUNT] = {5, 2, -1, 7, 1, 6, 3, 0};
    const unsigned logical[] = {0, 1500, 3100, 6200, 9000, 2049};
    const size_t count = sizeof(logical) / sizeof(logical[0]);

    puts("Q2: Paging address translation");
    printf("Page size = %u bytes; pages = %u\n", PAGE_SIZE, PAGE_COUNT);
    puts("Logical -> page, offset -> result");
    for (size_t i = 0; i < count; ++i) {
        unsigned address = logical[i];
        unsigned page = address / PAGE_SIZE;
        unsigned offset = address % PAGE_SIZE;
        printf("%5u -> page %u offset %7u : ", address, page, offset);
        if (page >= PAGE_COUNT)
            puts("invalid logical address");
        else if (page_table[page] < 0)
            puts("page fault (page is not resident)");
        else {
            unsigned physical = (unsigned)page_table[page] * PAGE_SIZE + offset;
            printf("physical address %u\n", physical);
        }
    }
    return 0;
}
