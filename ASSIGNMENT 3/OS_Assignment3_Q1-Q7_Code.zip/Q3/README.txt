AIM
Demonstrate segmentation using segment number, base, limit, offset and physical address, including an invalid offset.

SOURCE FILES
segmentation.c (safe table-based simulation)
segfault.c (optional OS-level invalid-memory demonstration)

COMPILE
gcc -std=c11 -Wall -Wextra segmentation.c -o segmentation
gcc -std=c11 -Wall -Wextra segfault.c -o segfault

EXECUTE
./segmentation
./segmentation &
PID=$!
cat /proc/$PID/maps
wait $PID
Optional fault demonstration: ./segfault (the OS should terminate it; exact shell wording varies).

REQUIRED LINUX COMMANDS
cat /proc/<PID>/maps
Use the PID printed by your own shell/process. Do not copy an example PID.

EXPECTED OUTPUT
Eight translations are printed. Valid offsets produce base+offset; offsets above the segment limit report SEGMENTATION FAULT. The optional null-pointer program causes a real OS fault on typical Linux systems. Do not run it where core dumps are undesirable.
