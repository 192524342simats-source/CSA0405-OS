#include <stdio.h>
int main(void)
{
    volatile int *invalid = (int *)0;
    puts("About to access an invalid address (expected process fault).");
    *invalid = 10;
    return 0;
}
