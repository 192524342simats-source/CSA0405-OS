#include <stdio.h>

typedef struct {
    const char *name;
    unsigned base;
    unsigned limit; /* maximum valid offset, inclusive */
} Segment;

int main(void)
{
    const Segment table[] = {
        {"code",  1000, 399},
        {"data",  5000, 999},
        {"stack", 9000, 499},
        {"heap", 12000, 799}
    };
    const unsigned requests[][2] = {
        {0, 0}, {0, 120}, {0, 399}, {0, 400},
        {1, 10}, {1, 999}, {1, 1000}, {2, 250}
    };
    puts("Q3: Segmentation translation (base + offset, subject to limit)");
    for (size_t i = 0; i < sizeof(requests)/sizeof(requests[0]); ++i) {
        unsigned s = requests[i][0], offset = requests[i][1];
        if (s >= sizeof(table)/sizeof(table[0])) {
            printf("Segment %u offset %u -> invalid segment\n", s, offset);
        } else if (offset > table[s].limit) {
            printf("Segment %u (%s), offset %u -> SEGMENTATION FAULT (limit %u)\n",
                   s, table[s].name, offset, table[s].limit);
        } else {
            printf("Segment %u (%s), offset %u -> physical %u\n",
                   s, table[s].name, offset, table[s].base + offset);
        }
    }
    return 0;
}
