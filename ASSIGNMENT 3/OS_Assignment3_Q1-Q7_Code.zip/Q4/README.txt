AIM
Demonstrate allocated virtual memory, sequential and page-stride access, checksum, timing, resource usage and fork copy-on-write behaviour.

SOURCE FILE
virtual_memory.c

COMPILE
gcc -std=c11 -O2 -Wall -Wextra virtual_memory.c -o virtual_memory

EXECUTE
./virtual_memory
/usr/bin/time -v ./virtual_memory

REQUIRED LINUX COMMANDS
/usr/bin/time -v ./virtual_memory

EXPECTED OUTPUT
The program reports access durations, checksums, minor/major faults observed in the measured section, and parent/child values. Timings, fault counts, maximum resident set size and time(1) fields depend on the host, compiler, kernel and system load; collect them on your own Ubuntu/WSL system.
