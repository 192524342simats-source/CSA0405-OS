#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

static double seconds(struct timespec a, struct timespec b)
{
    return (double)(b.tv_sec-a.tv_sec) + (double)(b.tv_nsec-a.tv_nsec)/1e9;
}

int main(void)
{
    const size_t n = 32u * 1024u * 1024u; /* 32 MiB */
    unsigned char *mem = malloc(n);
    if (!mem) { perror("malloc"); return 1; }

    struct timespec a, b;
    volatile uint64_t checksum = 0;
    clock_gettime(CLOCK_MONOTONIC, &a);
    for (size_t i=0; i<n; ++i) mem[i] = (unsigned char)(i % 251u);
    for (size_t i=0; i<n; ++i) checksum += mem[i];
    clock_gettime(CLOCK_MONOTONIC, &b);
    printf("Sequential access: %.6f s, checksum=%llu\n",
           seconds(a,b), (unsigned long long)checksum);

    checksum = 0;
    clock_gettime(CLOCK_MONOTONIC, &a);
    for (size_t i=0; i<n; i += 4096) checksum += mem[i];
    clock_gettime(CLOCK_MONOTONIC, &b);
    printf("Page-stride access: %.6f s, checksum=%llu\n",
           seconds(a,b), (unsigned long long)checksum);

    struct rusage before, after;
    getrusage(RUSAGE_SELF, &before);
    for (size_t i=0; i<n; i += 4096) mem[i] ^= 0x5a;
    getrusage(RUSAGE_SELF, &after);
    printf("Minor faults during measured section: %ld\n",
           after.ru_minflt - before.ru_minflt);
    printf("Major faults during measured section: %ld\n",
           after.ru_majflt - before.ru_majflt);

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); free(mem); return 1; }
    if (pid == 0) {
        mem[0] ^= 1; /* copy-on-write on a private mapping */
        printf("Child wrote to private page; child value=%u\n", mem[0]);
        free(mem);
        _exit(0);
    }
    waitpid(pid, NULL, 0);
    printf("Parent value after child write=%u (parent remains private)\n", mem[0]);

    free(mem);
    return 0;
}
