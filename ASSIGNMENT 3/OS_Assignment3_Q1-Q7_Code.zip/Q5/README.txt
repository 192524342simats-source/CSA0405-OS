AIM
Compare FIFO, LRU and Optimal page replacement and demonstrate Belady's anomaly.

SOURCE FILE
page_replacement.c

COMPILE
gcc -std=c11 -Wall -Wextra page_replacement.c -o page_replacement

EXECUTE
./page_replacement

REQUIRED LINUX COMMANDS
gcc -std=c11 -Wall -Wextra page_replacement.c -o page_replacement
./page_replacement

REFERENCE STRINGS
Main: 7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1
Belady: 1,2,3,4,1,2,5,1,2,3,4,5

EXPECTED OUTPUT
Main reference string: 3 frames FIFO 15, LRU 12, Optimal 9; 4 frames FIFO 10, LRU 8, Optimal 8.
Belady reference string: FIFO 3 frames 9 faults and 4 frames 10 faults.
