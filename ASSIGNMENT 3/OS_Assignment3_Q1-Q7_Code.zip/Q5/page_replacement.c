#include <stdio.h>
#define MAXF 16

static int find_page(const int f[], int used, int page)
{
    for (int i=0; i<used; ++i) if (f[i] == page) return i;
    return -1;
}
static int fifo(const int r[], int n, int frames)
{
    int f[MAXF], used=0, next=0, faults=0;
    for (int i=0; i<n; ++i) if (find_page(f,used,r[i]) < 0) {
        ++faults;
        if (used < frames) f[used++] = r[i];
        else { f[next]=r[i]; next=(next+1)%frames; }
    }
    return faults;
}
static int lru(const int r[], int n, int frames)
{
    int f[MAXF], last[MAXF], used=0, faults=0;
    for (int i=0; i<n; ++i) {
        int k=find_page(f,used,r[i]);
        if (k >= 0) { last[k]=i; continue; }
        ++faults;
        if (used < frames) { f[used]=r[i]; last[used++]=i; }
        else {
            int victim=0;
            for (int j=1; j<frames; ++j) if (last[j]<last[victim]) victim=j;
            f[victim]=r[i]; last[victim]=i;
        }
    }
    return faults;
}
static int optimal(const int r[], int n, int frames)
{
    int f[MAXF], used=0, faults=0;
    for (int i=0; i<n; ++i) {
        if (find_page(f,used,r[i]) >= 0) continue;
        ++faults;
        if (used < frames) { f[used++]=r[i]; continue; }
        int victim=0, farthest=-1;
        for (int j=0; j<frames; ++j) {
            int next=n;
            for (int t=i+1; t<n; ++t) if (r[t]==f[j]) { next=t; break; }
            if (next>farthest) { farthest=next; victim=j; }
        }
        f[victim]=r[i];
    }
    return faults;
}
int main(void)
{
    const int ref[]={7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};
    const int belady[]={1,2,3,4,1,2,5,1,2,3,4,5};
    const int n=(int)(sizeof(ref)/sizeof(ref[0]));
    puts("Q5: Page replacement comparison");
    for (int fr=3; fr<=4; ++fr)
        printf("%d frames: FIFO %d, LRU %d, Optimal %d\n",
               fr, fifo(ref,n,fr), lru(ref,n,fr), optimal(ref,n,fr));
    printf("Belady string, FIFO: 3 frames %d faults, 4 frames %d faults\n",
           fifo(belady,12,3), fifo(belady,12,4));
    puts("Frame sweep (3 to 10):");
    for (int fr=3; fr<=10; ++fr)
        printf("%2d frames -> FIFO %2d, LRU %2d, Optimal %2d\n",
               fr, fifo(ref,n,fr), lru(ref,n,fr), optimal(ref,n,fr));
    return 0;
}
