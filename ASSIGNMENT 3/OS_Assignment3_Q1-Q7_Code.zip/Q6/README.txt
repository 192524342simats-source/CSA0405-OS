AIM
Inspect Linux block devices, active swap, partition tables and RAM/swap usage without changing storage.

SOURCE FILE
disk_inspection.sh

EXECUTE
chmod +x disk_inspection.sh
./disk_inspection.sh

REQUIRED LINUX COMMANDS
lsblk
swapon --show
sudo fdisk -l
free -h

EXPLANATION
lsblk lists block devices, partitions and mount points.
swapon --show lists active swap areas.
sudo fdisk -l lists detected disks and partition tables (read-only listing).
free -h reports RAM and swap totals/usage in human-readable units.

EXPECTED OUTPUT
Output reflects the actual machine. Disk names, capacities, partitions and swap values are intentionally not hard-coded. In WSL, the visible devices may differ from a native Ubuntu installation. Never run destructive partitioning/formatting commands for this exercise.
