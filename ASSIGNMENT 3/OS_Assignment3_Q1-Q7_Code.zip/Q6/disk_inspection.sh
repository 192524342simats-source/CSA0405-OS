#!/usr/bin/env bash
set -u
echo "Q6: Read-only disk and memory inspection"
echo
echo "$ lsblk"
lsblk
echo
echo "$ swapon --show"
swapon --show
echo
echo "$ sudo fdisk -l"
if command -v sudo >/dev/null 2>&1; then
    sudo fdisk -l
else
    echo "sudo is unavailable; run this command manually on Ubuntu."
fi
echo
echo "$ free -h"
free -h
echo
echo "All commands above inspect system state; no disk is modified."
