AIM
Demonstrate page locking and unlocking with mlock()/munlock(), repeated memory access, checksum and timing.

SOURCE FILE
memory_lock.c

COMPILE
gcc -std=c11 -O2 -Wall -Wextra memory_lock.c -o memory_lock

EXECUTE
sudo ./memory_lock

REQUIRED LINUX COMMANDS
ulimit -l
sudo ./memory_lock

EXPECTED OUTPUT
Shows allocated bytes, mlock success/failure, iteration count, elapsed time, checksum and munlock result. mlock may fail due to RLIMIT_MEMLOCK, permissions or container/WSL restrictions. Timing is measured on the executing host and must not be copied from a sample screenshot.
