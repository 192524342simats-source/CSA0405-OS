#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <errno.h>
#include <stdint.h>
#include <unistd.h>

static double elapsed(struct timespec a, struct timespec b)
{
    return (double)(b.tv_sec-a.tv_sec) + (double)(b.tv_nsec-a.tv_nsec)/1e9;
}
int main(void)
{
    const size_t bytes = 1024u * 1024u; /* 1 MiB */
    const unsigned long iterations = 1000000UL;
    unsigned char *memory = malloc(bytes);
    if (!memory) { perror("malloc"); return 1; }

    memset(memory, 0, bytes);
    printf("Allocated memory: %zu bytes\n", bytes);
    if (mlock(memory, bytes) == 0)
        puts("mlock: SUCCESS (pages are locked in RAM)");
    else
        printf("mlock: FAILED: %s (check RLIMIT_MEMLOCK/privileges)\n", strerror(errno));

    struct timespec start, end;
    volatile uint64_t checksum = 0;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (unsigned long i=0; i<iterations; ++i) {
        size_t index = (size_t)(i % bytes);
        memory[index] = (unsigned char)(memory[index] + 1u);
        checksum += memory[index];
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    printf("Iterations: %lu\n", iterations);
    printf("Elapsed time: %.6f seconds\n", elapsed(start,end));
    printf("Checksum: %llu\n", (unsigned long long)checksum);

    if (munlock(memory, bytes) == 0) puts("munlock: SUCCESS");
    else perror("munlock");
    free(memory);
    return 0;
}
