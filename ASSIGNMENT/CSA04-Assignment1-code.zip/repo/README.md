# CSA04 Operating Systems - Assignment 1 (Smart Hospital)

Name: ______________   Register Number: ______________
Compiler and version: gcc ____   Linux distribution and version: ____________
Compile command: gcc -std=c11 -Wall -Wextra -pthread -o <name> <file>.c

## Folders
- Task05/task5_demo.c       - read()/write() demo for strace
- Task06/task6.c            - completed TODO 1 (read/write copy, counts read() calls)
- Task06/copy_bench.c       - copy with any buffer size, for strace -c and time
- Task07/task7.c            - completed TODO 1 (fork, execlp, waitpid)
- Task07/task7_noflush.c    - fflush experiment (second fflush removed, exit(3))
- Task07/spawn_bench.c      - fork+exec vs posix_spawn, 1000 commands
- Task10/bench_proc_thread.c - 1000 processes vs 1000 threads
- Task10/run_all.sh         - compiles and runs everything, saves ./results

## How to run
Task05: gcc ... -o task5_demo task5_demo.c ; strace ./task5_demo
Task06: gcc ... -o task6 task6.c ; ./task6 ; strace -c ./task6
Task07: gcc ... -o task7 task7.c ; ./task7 ; ./task7_noflush > out.txt
Task10: cd Task10 ; ./run_all.sh

## Result of each task (fill in after running)
Task06: output matches expected (10001 / 21 / 4 read() calls): yes / no
Task07: output matches expected: yes / no ; duplicate lines when redirected: yes / no
Task10: summary of measurements: ____________
