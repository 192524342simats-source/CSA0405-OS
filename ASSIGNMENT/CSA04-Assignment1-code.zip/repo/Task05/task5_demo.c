#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

/* Task 5 demo: write a small file, read it back with read() and show it with write(). */
int main(void) {
    const char *msg = "Patient 1001: pulse 72, SpO2 98\n";
    int fd = open("patient.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return 1;
    write(fd, msg, 32);
    close(fd);

    char buf[64];
    fd = open("patient.txt", O_RDONLY);
    if (fd < 0) return 1;
    ssize_t n = read(fd, buf, sizeof buf);
    write(STDOUT_FILENO, buf, (size_t)n);
    close(fd);
    printf("pid = %d\n", (int)getpid());
    unlink("patient.txt");
    return 0;
}
