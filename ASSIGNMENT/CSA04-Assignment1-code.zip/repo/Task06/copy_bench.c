#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

/* Usage: ./copy_bench src dst bufsize
   Copies src to dst with read()/write() using any buffer size and prints the
   number of data read() calls and the elapsed wall-clock time. */
int main(int argc, char *argv[]) {
    if (argc != 4) { fprintf(stderr, "usage: %s src dst bufsize\n", argv[0]); return 2; }
    size_t bufsize = (size_t)strtoul(argv[3], NULL, 10);
    char *buf = malloc(bufsize);
    int in = open(argv[1], O_RDONLY);
    int out = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (!buf || in < 0 || out < 0) { perror("setup"); return 1; }
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    long reads = 0; ssize_t n;
    while ((n = read(in, buf, bufsize)) > 0) {
        reads++;
        ssize_t done = 0;
        while (done < n) {
            ssize_t w = write(out, buf + done, (size_t)(n - done));
            if (w < 0) { perror("write"); return 1; }
            done += w;
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &t1);
    double ms = (t1.tv_sec - t0.tv_sec) * 1e3 + (t1.tv_nsec - t0.tv_nsec) / 1e6;
    printf("buffer %zu bytes: %ld data reads, %.2f ms\n", bufsize, reads, ms);
    close(in); close(out); free(buf);
    return 0;
}
