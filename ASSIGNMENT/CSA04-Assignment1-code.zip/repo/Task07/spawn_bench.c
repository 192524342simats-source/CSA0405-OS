#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <spawn.h>
#include <sys/wait.h>
#include <time.h>

#define N 1000
extern char **environ;

static double now_ms(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1e3 + t.tv_nsec / 1e6;
}

int main(void) {
    char *argv[] = {"true", NULL};
    double t0 = now_ms();
    for (int i = 0; i < N; i++) {                 /* fork + exec */
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) { execvp("true", argv); _exit(127); }
        waitpid(pid, NULL, 0);
    }
    double t1 = now_ms();
    printf("fork+exec : %d commands in %.1f ms (%.1f us each)\n", N, t1 - t0, (t1 - t0) * 1000.0 / N);

    t0 = now_ms();
    for (int i = 0; i < N; i++) {                 /* posix_spawn */
        pid_t pid;
        if (posix_spawnp(&pid, "true", NULL, NULL, argv, environ) != 0) { perror("posix_spawnp"); return 1; }
        waitpid(pid, NULL, 0);
    }
    t1 = now_ms();
    printf("posix_spawn: %d commands in %.1f ms (%.1f us each)\n", N, t1 - t0, (t1 - t0) * 1000.0 / N);
    return 0;
}
