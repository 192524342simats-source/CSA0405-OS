#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/wait.h>
#include <time.h>

#define N 1000

static double now_ms(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1e3 + t.tv_nsec / 1e6;
}
static void *worker(void *arg) { (void)arg; return NULL; }

int main(void) {
    double t0 = now_ms();
    for (int i = 0; i < N; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) _exit(0);
        waitpid(pid, NULL, 0);
    }
    double t1 = now_ms();
    printf("%d processes (fork+wait): %.2f ms total, %.1f us each\n", N, t1 - t0, (t1 - t0) * 1000.0 / N);

    t0 = now_ms();
    for (int i = 0; i < N; i++) {
        pthread_t th;
        if (pthread_create(&th, NULL, worker, NULL) != 0) { perror("pthread_create"); return 1; }
        pthread_join(th, NULL);
    }
    t1 = now_ms();
    printf("%d threads (create+join): %.2f ms total, %.1f us each\n", N, t1 - t0, (t1 - t0) * 1000.0 / N);
    return 0;
}
