#!/bin/bash
# Run on Linux from inside the Task10 folder. Saves every output into ./results.
set -e
mkdir -p results
CFLAGS="-std=c11 -Wall -Wextra -pthread"
gcc $CFLAGS -o task5_demo ../Task05/task5_demo.c
gcc $CFLAGS -o task6 ../Task06/task6.c
gcc $CFLAGS -o copy_bench ../Task06/copy_bench.c
gcc $CFLAGS -o task7 ../Task07/task7.c
gcc $CFLAGS -o task7_noflush ../Task07/task7_noflush.c
gcc $CFLAGS -o bench_proc_thread bench_proc_thread.c
gcc $CFLAGS -o spawn_bench ../Task07/spawn_bench.c

{ uname -a; gcc --version | head -1; grep PRETTY_NAME /etc/os-release; } > results/system.txt

strace ./task5_demo       > results/task5_strace_full.txt 2>&1
strace -c ./task5_demo    > results/task5_strace_c.txt 2>&1
./task6                   > results/task6_output.txt
strace -c ./task6         > results/task6_strace_c.txt 2>&1
./task7                   > results/task7_terminal.txt
./task7 > results/task7_redirect_flush.txt
./task7_noflush > results/task7_redirect_noflush.txt

dd if=/dev/urandom of=big.dat bs=1M count=100 status=none
for b in 64 512 4096 65536 1048576; do
  { time ./copy_bench big.dat big.copy $b ; } > results/copy_b$b.txt 2>&1
  strace -c -e trace=read,write ./copy_bench big.dat big.copy $b > results/copy_b${b}_strace.txt 2>&1
done
head -c 1048576 big.dat > small.dat       # 1-byte buffer is run on 1 MB only
{ time ./copy_bench small.dat small.copy 1 ; } > results/copy_b1_1MB.txt 2>&1
rm -f big.dat big.copy small.dat small.copy

for i in 1 2 3; do ./bench_proc_thread; done > results/proc_vs_thread.txt
for i in 1 2 3; do ./spawn_bench; done > results/spawn_vs_forkexec.txt
echo "Done. See ./results"
